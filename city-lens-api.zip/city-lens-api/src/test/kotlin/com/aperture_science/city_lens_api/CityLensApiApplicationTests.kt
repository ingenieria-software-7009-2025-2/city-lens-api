package com.aperture_science.city_lens_api

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class CityLensApiApplicationTests {

	@Test
	fun contextLoads() {
	}

}
